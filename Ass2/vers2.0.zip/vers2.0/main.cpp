#include <opencv2/opencv.hpp>
#include <opencv2/tracking.hpp>
#include <opencv2/highgui.hpp>

#include <iostream>
#include <stdio.h>

using namespace cv;
using namespace std;


// GLOBAL ENVIROMENTS

// structure to give a label to each rectangle of detection
// struct obj_det{
//     Rect rect;
//     int64 ID;
//     int f_lost = -1;
//     bool mod = 0;
//     Mat hist;
//     Mat histimg = Mat::zeros(400, 640, CV_8UC3);
//     Mat backproj;

//     Rect rectC;
//     // TODO: add MASK field -> taken from the BG subtraction
//     //       add HIST fieldw
// };

// random color generator
// Fill the vector with random colors
void getRandomColors(vector<Scalar> &colors, int numColors)
{
    RNG rng(0);
    for(int i=0; i < numColors; i++)
    colors.push_back(Scalar(rng.uniform(0,255), rng.uniform(0, 255), rng.uniform(0, 255))); 
}

int main(){
    
    /*** Tracker Build ***/
    // create Tracker Boosting pointer
    Ptr<MultiTracker> tracker = TrackerKCF::create();

    // initialize MultiTracker boxes
    vector<Rect> bboxes;


    /*** Load and Check Video ***/
    // path to the sequence of images
    string path_to_img = "./Video/img1/%06d.jpg";
    // load the sequence of images
    VideoCapture sequence(path_to_img);
    // if video not load, return error
    if(!sequence.isOpened()){
        cout << "Error opening video file " << path_to_img << endl;
        return -1;
    }
    // create matrix frame
    Mat frame;
    // read first frame
    sequence >> frame;

    /*** Declaration of general Variable ***/
    // ...

    /*** Get bounding box for first frame ***/ // TODO: next will be generate from detector
    bool showCrosshair = true;
    bool fromCenter = false;
    cout << "\n========================================================\n";
    cout << "OpenCV says press c to cancel obj selection procedure\n"<<endl;
    cout << "It doesn't work, press Escape to exit selection procedure\n"<<endl;
    cout << "\n========================================================\n";

    cv::selectROIs("MultiTracker", frame, bboxes, showCrosshair,fromCenter);

    // quit if there are no obj to track
    if(bboxes.size() <1)
        return 0;
    
    vector<Scalar> colors;
    getRandomColors(colors,bboxes.size());

    /*** Initialize MultiTracker ***/
    Ptr<MultiTracker> multiTracker = MultiTracker::create();
    for( int i = 0; i <bboxes.size(); i++){
        multiTracker->add(tracker, frame, Rect2d(bboxes[i]));

    }

    /*** UPDATE & DISPLAY ***/
    while (sequence.isOpened()){
        sequence>>frame;
        
        if(frame.empty()) break;

        // Update multitracker result with new frame
        multiTracker -> update(frame);

        // Draw tracked objects
        for(unsigned i=0; i<multiTracker->getObjects().size();i++){
            rectangle(frame, multiTracker->getObjects()[i], colors[i], 2, 1);
        }

        // Show frame
        imshow("MultiTracker", frame);

        // quit on x button
        if(waitKey(1) == 27) break;

    }
    
    

    




    /*** ***/


    /*** ***/






    return 0;
}